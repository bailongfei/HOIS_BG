--工作站状态

CREATE VIEW [dbo].[View_WorkStation_Work]
AS
    SELECT TOP 1000
            A.WS_ID ,
            A.Staff_ID ,
            A.Staff_Code ,
            A.WS_Status_Type ,
            A.Track_No ,
            A.Queue_No ,
            A.SrvGroup_ID ,
            C.SrvGroup_Name ,
            A.SrvGroup_Letter ,
            A.SrvCode_ID ,
            D.SrvCode_Name ,
            A.Customer_ID ,
            A.Customer_Name ,
            A.WS_Display_Name ,
            A.DataID ,
            B.WS_Name ,
            B.WS_Terminal_ID ,
            B.WS_Display_ID ,
            B.WS_No ,
            E.Staff_Name ,
            E.Staff_Title ,
            E.Staff_UserRole ,
            E.Staff_Pic ,
            E.Staff_Priority
    FROM    dbo.Basic_WorkStation_Work A
            INNER JOIN dbo.Basic_WorkStation B ON A.WS_ID = B.WS_ID
            INNER JOIN dbo.Basic_SrvGroup C ON A.SrvGroup_ID = C.SrvGroup_ID
            LEFT JOIN dbo.Basic_SrvCode D ON D.SrvCode_ID = A.SrvCode_ID
            LEFT JOIN dbo.Basic_StaffInfo E ON A.Staff_ID = E.Staff_ID
    WHERE   B.WS_Enable = 1
            AND E.Staff_Enable = 1
    ORDER BY A.WS_ID

go

