-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-8
-- Description:	过号激活
-- =============================================
CREATE PROCEDURE [dbo].[SP_MS_Queue_Act] @Data_ID INT
AS 
    DECLARE @SrvGroup_ID INT 
    DECLARE @Queue_Pos INT 
    
    --获取当前的服务
    SELECT  @SrvGroup_ID = SrvGroup_ID
    FROM    dbo.Basic_Queue_Work
    WHERE   Data_ID = @Data_ID
    
    --获取该服务下的 未服务的第二位  Queue_Pos
    SELECT  @Queue_Pos = MAX(A.Queue_Pos)
    FROM    dbo.Basic_Queue_Work A
            INNER JOIN ( SELECT TOP 2
                                Data_ID ,
                                Queue_Pos
                         FROM   dbo.Basic_Queue_Work
                         WHERE  SrvGroup_ID = @SrvGroup_ID
                                AND Status_Type = 3
                         ORDER BY Queue_Pos ASC
                       ) B ON A.Data_ID = B.Data_ID  
    
    IF @Queue_Pos = NULL 
        BEGIN
            UPDATE  dbo.Basic_Queue_Work
            SET     Status_Type = 3 ,
                    Stamp_Time = GETDATE()
            WHERE   Data_ID = @Data_ID
        END
    ELSE 
        BEGIN
        --过好激活
            UPDATE  dbo.Basic_Queue_Work
            SET     Queue_Pos = @Queue_Pos + 1 ,
                    Stamp_Time = GETDATE() ,
                    Status_Type = 3 ,
                    WS_ID = 0
            WHERE   Data_ID = @Data_ID
        END

go

