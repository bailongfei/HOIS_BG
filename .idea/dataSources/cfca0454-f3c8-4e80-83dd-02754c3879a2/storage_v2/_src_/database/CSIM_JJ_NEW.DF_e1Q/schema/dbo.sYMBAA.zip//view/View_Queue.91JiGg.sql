--使用此视图  需要       Priority_ID  一个where条件
CREATE VIEW [dbo].[View_Queue]
AS
    SELECT TOP 100000
            A.Data_ID ,
            A.Customer_Name ,
            A.Start_Time ,
            A.End_Time ,
            A.Queue_No ,
            A.Queue_Pos ,
            A.SrvGroup_ID ,
            A.Status_Type ,
            A.WS_ID ,
            B.Priority_ID ,
            B.Priority_Level ,
            C.SrvGroup_Letter
    FROM    dbo.Basic_Queue_Work AS A
            INNER JOIN dbo.Basic_Priority AS B ON B.SrvGroup_ID = A.SrvGroup_ID
            INNER JOIN dbo.Basic_SrvGroup C ON A.SrvGroup_ID = C.SrvGroup_ID
    ORDER BY B.Priority_Level ASC ,
            A.Queue_Pos ASC ,
            A.Stamp_Time ASC

go

