






--不正常数据

CREATE VIEW [dbo].[View_Web_Stat_UnCommon]
AS
    SELECT  Data_ID ,
            Queue_No ,
            Track_No ,
            SrvGroup_ID ,
            CONVERT(VARCHAR(12), RegDate, 23) AS RegTime ,
            RegDate ,
            Start_Time ,
            Next_Time ,
            End_Time ,
            DATEDIFF(MINUTE, '8:00:00', CONVERT(VARCHAR(12), RegDate, 108)) AS EnterMinute ,
            DATEDIFF(MINUTE, Start_Time, Next_Time) AS WaitMinute ,
            DATEDIFF(MINUTE, Next_Time, End_Time) AS WorkMinute ,
            DATENAME(weekday, RegDate) AS DName ,
            Staff_ID ,
            Staff_Code,
            WS_ID
    FROM    dbo.Basic_Queue_Stat
    WHERE   Next_Time IS  NULL
            OR Confirm_Time IS  NULL
            OR End_Time IS   NULL



go

