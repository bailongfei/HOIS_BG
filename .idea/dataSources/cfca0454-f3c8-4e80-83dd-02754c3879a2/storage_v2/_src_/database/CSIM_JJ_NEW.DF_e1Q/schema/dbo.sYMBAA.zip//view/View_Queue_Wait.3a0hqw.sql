
--未呼叫

CREATE VIEW [dbo].[View_Queue_Wait]
AS
    SELECT  *
    FROM    dbo.Basic_Queue_Work
    WHERE   Status_Type =3


go

