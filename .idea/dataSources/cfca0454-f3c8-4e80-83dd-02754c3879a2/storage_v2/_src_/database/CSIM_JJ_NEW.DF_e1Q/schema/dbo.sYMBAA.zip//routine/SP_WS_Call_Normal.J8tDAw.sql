-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-9
-- Description:	呼叫下一位

-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Call_Normal]
    @WS_ID INT ,
    @Pre_DataID INT--前一位客户
AS --自定义变量
    DECLARE @Priority_ID INT 
    DECLARE @DataID INT --当前呼叫的客户
    DECLARE @Next_DataID INT --下一位客户
    
    DECLARE @Staff_ID INT 
    DECLARE @Staff_Code NVARCHAR(20)
    DECLARE @Staff_Name NVARCHAR(50)
    
    DECLARE @WS_Name VARCHAR(30)
    DECLARE @WS_No NVARCHAR(30) 
    DECLARE @WS_Display_ID INT
    DECLARE @WS_Display_Type INT 
    DECLARE @WS_Display_Name NVARCHAR(20)
    
    DECLARE @SrvGroup_ID INT 
    DECLARE @SrvCode_ID INT 
    DECLARE @SrvGroup_Name NVARCHAR(100) 
    DECLARE @SrvGroup_Letter VARCHAR(2)
    
    DECLARE @Track_No INT 
    DECLARE @Queue_No INT --当前客户的队列号
    DECLARE @Next_Queue_No INT --下一位客户的队列号
    DECLARE @Customer_ID NVARCHAR(30)
    DECLARE @Customer_Name NVARCHAR(30)--当前客户的姓名
    DECLARE @Next_Customer_Name NVARCHAR(30)--下一位客户的姓名
    DECLARE @Customer_Type INT
    

    --获取员工信息  Staff_ID/Staff_Code
    SELECT  @Staff_ID = Staff_ID ,
            @Staff_Code = Staff_Code ,
            @WS_Name = B.WS_Name ,
            @WS_No = B.WS_No ,
            @WS_Display_ID = WS_Display_ID ,
            @WS_Display_Type = WS_Display_Type ,
            @WS_Display_Name = WS_Display_Name
    FROM    dbo.Basic_WorkStation_Work A
            INNER JOIN dbo.Basic_WorkStation B ON A.WS_ID = B.WS_ID
    WHERE   A.WS_ID = @WS_ID
    
    --获取员工姓名
    SELECT  @Staff_Name = Staff_Name
    FROM    dbo.Basic_StaffInfo
    WHERE   Staff_Code = @Staff_Code
    
    --更新上一位客户信息
    UPDATE  dbo.Basic_Queue_Work
    SET     End_Time = GETDATE() ,
            Stamp_Time = GETDATE() ,
            WS_ID = @WS_ID ,
            Staff_ID = @Staff_ID ,
            Staff_Code = @Staff_Code ,
            Queue_Pos = -1 ,
            Status_Type = 21
    WHERE   Data_ID = @Pre_DataID
    
    --获取 工作站当前工作  优先级  
    SELECT  @Priority_ID = WS_Preiod_Work
    FROM    dbo.Basic_WorkStation_Work
    WHERE   WS_ID = @WS_ID
    
    --获取下一位客户Queue_Word 主键
    SELECT TOP 1
            @DataID = Data_ID
    FROM    dbo.View_Queue
    WHERE   Status_Type = 3
            AND dbo.View_Queue.Priority_ID = @Priority_ID
            
    --获取下一位客户 SrvGroup_ID/SrvCode_ID
    SELECT  @SrvGroup_ID = SrvGroup_ID ,
            @SrvCode_ID = SrvCode_ID ,
            @Track_No = Track_No ,
            @Queue_No = Queue_No ,
            @Customer_ID = Customer_ID ,
            @Customer_Name = Customer_Name ,
            @Customer_Type = Customer_Type
    FROM    dbo.Basic_Queue_Work
    WHERE   Data_ID = @DataID
    
    SELECT  @SrvGroup_Name = SrvGroup_Name ,
            @SrvGroup_Letter = SrvGroup_Letter
    FROM    dbo.Basic_SrvGroup
    WHERE   SrvGroup_ID = @SrvGroup_ID
    
    IF @SrvGroup_ID IS NOT NULL 
        BEGIN --如果还有用户
            --更新Workstation_work表
            UPDATE  dbo.Basic_WorkStation_Work
            SET     WS_Status_Type = 3 ,--正在服务
                    Track_No = @Track_No ,
                    Queue_No = @Queue_No ,
                    SrvCode_ID = @SrvCode_ID ,
                    SrvGroup_ID = @SrvGroup_ID ,
                    SrvGroup_Letter = @SrvGroup_Letter ,
                    Customer_ID = @Customer_ID ,
                    Customer_Name = @Customer_Name ,
                    Customer_Type = @Customer_Type ,
                    DataID = @DataID--当前服务客户
            WHERE   WS_ID = @WS_ID
    
                            
            --返回下一位客户信息
            SELECT TOP 1
                    *
            FROM    dbo.View_Queue
            WHERE   Status_Type = 3
                    AND Data_ID = @DataID
    
            --更新下一位客户状态
            UPDATE  dbo.Basic_Queue_Work
            SET     Status_Type = 11 ,--第一次被呼叫
                    Next_Time = GETDATE() ,
                    End_Time = GETDATE() ,
                    Stamp_Time = GETDATE() ,
                    WS_ID = @WS_ID ,
                    Call_Times = 1 ,--第一次被呼叫
                    Staff_ID = @Staff_ID ,
                    Staff_Code = @Staff_Code
            WHERE   Data_ID = @DataID
    
            --获取等候客户
            SELECT TOP 1
                    @Next_Queue_No = Queue_No ,
                    @Next_Customer_Name = Customer_Name
            FROM    dbo.View_Queue
            WHERE   Status_Type = 3
                    AND dbo.View_Queue.Priority_ID = @Priority_ID
             
             
                    
            IF ( @Next_Customer_Name IS NULL ) 
                BEGIN
                    SET @Next_Customer_Name = N'' 
                END
        
            IF ( @Next_Queue_No IS NULL ) 
                BEGIN
                    SET @Next_Queue_No = 0
                END
                
                
                
            --******************2014-4-24 去掉候诊客户
            SET @Next_Customer_Name = N'' 
            SET @Next_Queue_No = 0
            --******************
        
            --插入CMD 
            EXEC SP_Cmd_WS_Call_Normal @SrvGroup_ID, @SrvGroup_Name,
                @SrvGroup_Letter, @Queue_No, @Customer_Name, @Next_Queue_No,
                @Next_Customer_Name, @WS_ID, @WS_No, @WS_Name, @WS_Display_ID,
                @WS_Display_Type, @WS_Display_Name, @Staff_Name
     
        END

go

