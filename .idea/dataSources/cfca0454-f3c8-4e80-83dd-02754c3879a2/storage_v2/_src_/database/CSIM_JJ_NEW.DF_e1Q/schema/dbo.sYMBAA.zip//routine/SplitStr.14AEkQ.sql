CREATE   FUNCTION [dbo].[SplitStr]
    (
      @SourceSql VARCHAR(8000) ,
      @StrSeprate VARCHAR(100)
    )
RETURNS @temp TABLE ( F1 VARCHAR(100) )
AS 
    BEGIN   
        DECLARE @ch AS VARCHAR(100)   
        SET @SourceSql = @SourceSql + @StrSeprate     
        WHILE ( @SourceSql <> '' ) 
            BEGIN   
                SET @ch = LEFT(@SourceSql, CHARINDEX(',', @SourceSql, 1) - 1)   
                INSERT  @temp
                VALUES  ( @ch )   
                SET @SourceSql = STUFF(@SourceSql, 1,
                                       CHARINDEX(',', @SourceSql, 1), '')   
            END   
        RETURN   
    END

go

