CREATE VIEW [dbo].[View_CMD_WorkStation]
AS
    SELECT  ControlCmd_ID ,
            ControlCmd_Time ,
            Cmd_Group_ID ,
            Cmd_Type_ID ,
            Cmd_Info ,
            Cmd_Para_1 ,
            Cmd_Para_2 ,
            Cmd_Para_3 ,
            Cmd_Para_4 ,
            Cmd_Status
    FROM    dbo.Basic_ControlCmd
    WHERE   Cmd_Group_ID = 2
            AND Cmd_Status = 0

go

