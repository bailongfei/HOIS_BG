--已呼叫

CREATE VIEW [dbo].[View_Queue_Finish]
AS
    SELECT  *
    FROM    dbo.Basic_Queue_Work
    WHERE   Status_Type > 10

go

