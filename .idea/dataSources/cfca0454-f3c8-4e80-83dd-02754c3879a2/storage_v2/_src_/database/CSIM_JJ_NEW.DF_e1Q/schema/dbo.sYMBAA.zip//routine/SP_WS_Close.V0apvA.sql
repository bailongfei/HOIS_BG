-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-8
-- Description:	工作站关闭
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Close] @WS_ID INT
AS --更新工作站  信息

    DECLARE @WS_Display_ID INT 
    DECLARE @WS_Display_Type INT 
    DECLARE @WS_No NVARCHAR(30) 
    DECLARE @WS_Scroll_Txt NVARCHAR(100)
    DECLARE @WS_Name NVARCHAR(100)
    DECLARE @WS_Display_Name NVARCHAR(100)
    DECLARE @Staff_Name NVARCHAR(30)
    DECLARE @Staff_ID INT 

    SELECT  @WS_Display_ID = WS_Display_ID ,
            @WS_Display_Type = WS_Display_Type ,
            @WS_No = WS_No ,
            @WS_Scroll_Txt = WS_Scroll_Txt ,
            @WS_Name = WS_Name ,
            @WS_Display_Name = WS_Display_Name ,
            @Staff_ID = Staff_ID
    FROM    dbo.Basic_WorkStation_Work A
            INNER JOIN dbo.Basic_WorkStation B ON A.WS_ID = B.WS_ID
    WHERE   A.WS_ID = @WS_ID
    
    SELECT  @Staff_Name = Staff_Name
    FROM    dbo.Basic_StaffInfo
    WHERE   Staff_ID = @Staff_ID

    UPDATE  dbo.Basic_WorkStation_Work
    SET     --Staff_ID = NULL ,
    --        Staff_Code = NULL ,
            WS_Status_Type = 1 ,--工作站窗口停止 
            WS_LogOut_Time = GETDATE() ,
            Queue_No = 0 ,
            Track_No = 0
            --,
            --Track_No = 0 ,
            --Queue_No = 0,
            --DataID=0
    WHERE   WS_ID = @WS_ID
    
    --更新上一位客户信息   (非法操作导致状态未修改的情况)
    UPDATE  dbo.Basic_Queue_Work
    SET     Status_Type = 21 ,
            Stamp_Time = GETDATE() ,
            End_Time = GETDATE()
    WHERE   WS_ID = @WS_ID
            AND Status_Type BETWEEN 11 AND 20
    
    
    --插入cmd  工作站关闭
    EXEC dbo.SP_Cmd_WS_Close @WS_ID, @WS_Display_ID, @WS_Display_Type,
        @WS_Scroll_Txt, @WS_Name, @WS_No, @WS_Display_Name, @Staff_Name
    
    SELECT  1

go

