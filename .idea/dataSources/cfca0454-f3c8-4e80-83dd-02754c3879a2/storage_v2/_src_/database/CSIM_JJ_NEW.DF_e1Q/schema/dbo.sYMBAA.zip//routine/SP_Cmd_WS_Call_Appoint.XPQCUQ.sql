-- =============================================
-- Author:		
-- Create date: <Create Date,,>
-- Description:指定呼叫插入cmd
-- =============================================
CREATE PROCEDURE [dbo].[SP_Cmd_WS_Call_Appoint]
 --服务
    @SrvGroup_ID INT ,
    @SrvGroup_Name VARCHAR(30) ,
    @SrvGroup_Letter VARCHAR(30) ,
    
    --队列
    @Queue_No INT ,
    @Customer_Name VARCHAR(30) ,
    @Next_Queue_No INT ,
    @Next_Customer_Name VARCHAR(30) ,
    
    --工作站
    @WS_ID INT ,
    @WS_No NVARCHAR(30) ,
    @WS_Name VARCHAR(30) ,
    @WS_Display_ID INT ,
    @WS_Display_Type INT ,
    @WS_Display_Name NVARCHAR(20) ,
    
    --员工
    @Staff_Name VARCHAR(30)
AS --大屏,插入cmd表,
    INSERT  INTO dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    1 ,
                    1 ,
                    '' ,
                    MD_ID , -- Cmd_Para_1 - nvarchar(50)
                    CONVERT(VARCHAR(30), MD_Type) + '|'
                    + CONVERT(VARCHAR(30), MD_Display_Mode) , -- Cmd_Para_2 - nvarchar(50)
                    @SrvGroup_Name + '|' + @SrvGroup_Letter + '|'
                    + CASE LEN(CONVERT(NVARCHAR(10), @Queue_No))
                        WHEN 4 THEN CONVERT(NVARCHAR(10), @Queue_No)
                        ELSE ( REPLICATE('0',
                                         3
                                         - LEN(CONVERT(VARCHAR(30), @Queue_No)))
                               + CONVERT(VARCHAR(30), @Queue_No) )
                      END + '|' + @Customer_Name , -- Cmd_Para_3 - nvarchar(50)
                    @WS_Name + '|' + CONVERT(VARCHAR(30), @WS_No) + '|'
                    + @Staff_Name + '|' + CONVERT(NVARCHAR(10), @WS_ID) , -- Cmd_Para_4 - nvarchar(50)
                    0  -- Cmd_Status - smallint
            FROM    dbo.Basic_MainDisplay
            WHERE   MD_WS_ID LIKE '%,' + CONVERT(VARCHAR(30), @WS_ID) + ',%'
                            
                            
    --工作站,插入cmd表,
    INSERT  INTO dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
    VALUES  ( GETDATE() , -- ControlCmd_Time - datetime
              2 ,
              1 ,
              '' ,
              @WS_ID , -- Cmd_Para_1 - nvarchar(50)
              CONVERT(VARCHAR(30), @WS_Display_ID) + '|'
              + CONVERT(VARCHAR(30), @WS_Display_Type) , -- Cmd_Para_2 - nvarchar(50)
              @SrvGroup_Name + '|' + @SrvGroup_Letter + '|'
              + CASE LEN(CONVERT(NVARCHAR(10), @Queue_No))
                  WHEN 4 THEN CONVERT(NVARCHAR(10), @Queue_No)
                  ELSE ( REPLICATE('0',
                                   3 - LEN(CONVERT(VARCHAR(30), @Queue_No)))
                         + CONVERT(VARCHAR(30), @Queue_No) )
                END + '|' + @Customer_Name , -- Cmd_Para_3 - nvarchar(50)
              @WS_Name + '|' + CONVERT(VARCHAR(30), @WS_No) + '|'
              + @Staff_Name , -- Cmd_Para_4 - nvarchar(50)
              0  -- Cmd_Status - smallint
            )
            
            
    --语音,插入cmd表,
    INSERT  INTO dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    3 ,
                    3 ,
                    '' ,
                    MD_ID , -- Cmd_Para_1 - nvarchar(100)
                    ( SELECT    SrvGroup_Name + '|' + SrvGroup_Letter
                      FROM      dbo.Basic_SrvGroup
                      WHERE     SrvGroup_ID = @SrvGroup_ID
                    ) + '|' + CASE LEN(CONVERT(NVARCHAR(10), @Queue_No))
                                WHEN 4 THEN CONVERT(NVARCHAR(10), @Queue_No)
                                ELSE ( REPLICATE('0',
                                                 3
                                                 - LEN(CONVERT(VARCHAR(30), @Queue_No)))
                                       + CONVERT(VARCHAR(30), @Queue_No) )
                              END + '|' + @Customer_Name ,-- Cmd_Para_2 - nvarchar(100)
                    @WS_Name + '|' + @WS_No + '|' + @WS_Display_Name ,-- Cmd_Para_3 - nvarchar(50)
                    N'' , -- Cmd_Para_4 - nvarchar(50)
                    0  -- Cmd_Status - smallint
            FROM    dbo.Basic_MainDisplay
            WHERE   MD_WS_ID LIKE '%,' + CONVERT(VARCHAR(30), @WS_ID) + ',%'

go

