-- =============================================
-- Author:		吕东来	
-- Create date: 2014-4-8
-- Description:	工作站开启

--返回数据   DataSet
--1.是否成功
--2.员工数据
--3.返回Basic_Priority_Basic表的Priority_ID（-1代表没有选择优先级）
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Open]
    @WS_ID INT ,
    @Staff_LoginName NVARCHAR(20) ,
    @Staff_Pass NVARCHAR(20)
AS 
    DECLARE @PreiodMode INT
    DECLARE @PRIORITYID INT
    DECLARE @Staff_ID INT 
    DECLARE @Staff_Code NVARCHAR(20)
    DECLARE @Staff_Name VARCHAR(30)
    DECLARE @Staff_Level INT 
    DECLARE @Staff_Title VARCHAR(30)
    DECLARE @Staff_Pic NVARCHAR(200)
    
    DECLARE @WS_Display_ID INT 
    DECLARE @WS_Display_Type INT 
    DECLARE @WS_Scroll_Txt NVARCHAR(100)
    DECLARE @WS_No NVARCHAR(20) 
    DECLARE @WS_Name VARCHAR(30)
    DECLARE @WS_Display_Name VARCHAR(30)
    
    --判断用户名密码是否正确
    IF ( SELECT COUNT(*)
         FROM   dbo.Basic_StaffInfo
         WHERE  Staff_LoginName = @Staff_LoginName
                AND Staff_Pass = @Staff_Pass
                AND Staff_Enable = 1
       ) = 1 
        BEGIN
            SELECT  1 --登录成功
            
            --初始化工作站（非法关机造成）(胎心监护工作站除外)
            IF @WS_ID <> 9 
                BEGIN
                    UPDATE  dbo.Basic_Queue_Work
                    SET     Status_Type = 21 ,
                            Queue_Pos = -1
                    WHERE   WS_ID = @WS_ID
                            AND Status_Type BETWEEN 11 AND 20
                END     
            
            --获取两个变量
            SELECT  @Staff_ID = Staff_ID ,
                    @Staff_Code = Staff_Code
            FROM    dbo.Basic_StaffInfo
            WHERE   Staff_LoginName = @Staff_LoginName
                    AND Staff_Pass = @Staff_Pass
                    AND Staff_Enable = 1
                    
            --返回员工信息
            SELECT  *
            FROM    dbo.Basic_StaffInfo
            WHERE   Staff_LoginName = @Staff_LoginName
                    AND Staff_Pass = @Staff_Pass
                    AND Staff_Enable = 1
                    
            SELECT  @Staff_Name = Staff_Name ,
                    @Staff_Level = Staff_Level ,
                    @Staff_Title = Staff_Title ,
                    @Staff_Pic = Staff_Pic
            FROM    dbo.Basic_StaffInfo
            WHERE   Staff_LoginName = @Staff_LoginName
                    AND Staff_Pass = @Staff_Pass
                    AND Staff_Enable = 1 
                   
            --取优先级模式
            SELECT  @PreiodMode = WS_Priority_Type ,
                    @WS_Display_ID = WS_Display_ID ,
                    @WS_Display_Type = WS_Display_Type ,
                    @WS_Scroll_Txt = WS_Scroll_Txt ,
                    @WS_No = WS_No ,
                    @WS_Name = WS_Name ,
                    @WS_Display_Name = WS_Display_Name
            FROM    dbo.Basic_WorkStation A
                    INNER JOIN dbo.Basic_WorkStation_Work B ON A.WS_ID = B.WS_ID
            WHERE   A.WS_ID = @WS_ID
            
            
            --自定义
            IF @PreiodMode = 0 
                BEGIN
                    SELECT  0 
                END 
            
            --取Staff
            IF @PreiodMode = 1 
                BEGIN
             
                    SELECT  @PRIORITYID = Staff_Priority
                    FROM    dbo.Basic_StaffInfo
                    WHERE   Staff_LoginName = @Staff_LoginName
                            AND Staff_Pass = @Staff_Pass
                            AND Staff_Enable = 1 
                    
                    IF @PRIORITYID = 0 
                        BEGIN
                            --没有优先级
                            SELECT  -1
                        END
                    ELSE 
                        BEGIN
                            --返回优先级
                            SELECT  @PRIORITYID
                        END
                    
                END 
                
            --取WorkStation   
            IF @PreiodMode = 2 
                BEGIN
                    SELECT  @PRIORITYID = WS_Priority
                    FROM    dbo.Basic_WorkStation
                    WHERE   WS_ID = @WS_ID
                    
                    IF @PRIORITYID = 0 
                        BEGIN
                            --没有优先级
                            SELECT  -1
                        END
                    ELSE 
                        BEGIN
                        
                        --返回优先级
                            SELECT  @PRIORITYID                  
                        END
                END 
                
            --更新Basic_WorkStation_Work
            UPDATE  dbo.Basic_WorkStation_Work
            SET     Staff_ID = @Staff_ID ,
                    Staff_Code = @Staff_Code ,
                    WS_Status_Type = 2 ,--工作站开放，没有客户
                    WS_LogIn_Time = GETDATE() ,
                    WS_Preiod_Work = @PRIORITYID --更新WS当前工作优先级字段
            WHERE   WS_ID = @WS_ID
            
            IF ( @WS_Display_Name IS NULL ) 
                BEGIN
                    SET @WS_Display_Name = N''
                END 
            
            --插入cmd
            EXEC SP_Cmd_WS_Open @WS_ID, @WS_Display_ID, @WS_Display_Type,
                @WS_Scroll_Txt, @WS_No, @WS_Name, @WS_Display_Name,
                @Staff_Code, @Staff_Name, @Staff_Level, @Staff_Title,
                @Staff_Pic 
        END
    ELSE 
        BEGIN
            SELECT  2 --登录失败
        END

go

